JP_CONFIG['owlCarousel'] = {
  rtl : true
};
